import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _696726a9 = () => interopDefault(import('../pages/books.vue' /* webpackChunkName: "pages/books" */))
const _4ac81880 = () => interopDefault(import('../pages/repos.vue' /* webpackChunkName: "pages/repos" */))
const _0094ca88 = () => interopDefault(import('../pages/events/all.vue' /* webpackChunkName: "pages/events/all" */))
const _ab9adbb2 = () => interopDefault(import('../pages/download/_category.vue' /* webpackChunkName: "pages/download/_category" */))
const _81c76dc8 = () => interopDefault(import('../pages/post/_id.vue' /* webpackChunkName: "pages/post/_id" */))
const _80ec4e5e = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))
const _8aea82d8 = () => interopDefault(import('../pages/index/index.vue' /* webpackChunkName: "pages/index/index" */))
const _38f720c2 = () => interopDefault(import('../pages/index/_welcome/_category.vue' /* webpackChunkName: "pages/index/_welcome/_category" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
      path: "/books",
      component: _696726a9,
      name: "books"
    }, {
      path: "/repos",
      component: _4ac81880,
      name: "repos"
    }, {
      path: "/events/all",
      component: _0094ca88,
      name: "events-all"
    }, {
      path: "/download/:category?",
      component: _ab9adbb2,
      name: "download-category"
    }, {
      path: "/post/:id?",
      component: _81c76dc8,
      name: "post-id"
    }, {
      path: "/",
      component: _80ec4e5e,
      children: [{
        path: "",
        component: _8aea82d8,
        name: "index"
      }, {
        path: ":welcome/:category?",
        component: _38f720c2,
        name: "index-welcome-category"
      }]
    }],

  fallback: false
}

export function createRouter() {
  return new Router(routerOptions)
}
